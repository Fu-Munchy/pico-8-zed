function some_function()
    -- some comment
    return 123
end
